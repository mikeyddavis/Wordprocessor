﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Word_Press_Final
{
    public partial class Word : Form
    {
        string theFile;

        public Word()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            theFile = "Unsaved File";
            this.Text= theFile;
            saveToolStripMenuItem.Enabled = false;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            theFile = "Unsaved File";
            this.Text = theFile;
            saveToolStripMenuItem.Enabled = false;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                openFileDialog1.Filter = "Text File *.txt | *.txt | Rich Text Files *.rtf | *.rtf | All Files *.* | *.*";

                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    theFile = openFileDialog1.FileName;

                    saveToolStripMenuItem.Enabled = true;

                    this.Text = theFile;

                    var streamReader = openFileDialog1.OpenFile();

                    using (StreamReader reader = new StreamReader(streamReader))
                    {
                        richTextBox1.Text = reader.ReadToEnd();
                        reader.Close();
                    }
                }
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog1 = new SaveFileDialog())
            {
                saveFileDialog1.Filter = "Rich Text Files *.rtf | *.rtf";

                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    theFile = saveFileDialog1.FileName;

                    saveToolStripMenuItem.Enabled = true;

                    this.Text = theFile;

                    using (StreamWriter streamWrite = new StreamWriter(theFile))
                    {
                        streamWrite.Write(richTextBox1.Text);
                        streamWrite.Close();
                    }
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (StreamWriter streamWrite = new StreamWriter(theFile))
            {
                streamWrite.Write(richTextBox1.Text);
                streamWrite.Close();
            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog1 = new FontDialog();

            fontDialog1.Font = richTextBox1.SelectionFont;

            if (fontDialog1.ShowDialog() == DialogResult.OK & !String.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionFont = fontDialog1.Font;
            }
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog1 = new ColorDialog();

            colorDialog1.Color = richTextBox1.SelectionColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK & !String.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionColor = colorDialog1.Color;
            }
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog1 = new ColorDialog();

            colorDialog1.Color = richTextBox1.SelectionColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK & !String.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionBackColor = colorDialog1.Color;
            }
        }

        private void undoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void toolStripButtonUndo_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void redoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void toolStripButtonRedo_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void copyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox1.SelectedText, TextDataFormat.Text);
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox1.SelectedText, TextDataFormat.Text);
        }

        private void toolStripButtonSave_Click(object sender, EventArgs e)
        {
            using (StreamWriter streamWrite = new StreamWriter(theFile))
            {
                streamWrite.Write(richTextBox1.Text);
                streamWrite.Close();
            }
        }

        private void toolStripButtonNewFile_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            theFile = "Unsaved File";
            this.Text = theFile;
            saveToolStripMenuItem.Enabled = false;
        }

        private void toolStripButtonOpenFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                openFileDialog1.Filter = "Text File *.txt | *.txt | Rich Text Files *.rtf | *.rtf | All Files *.* | *.*";

                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    theFile = openFileDialog1.FileName;

                    saveToolStripMenuItem.Enabled = true;

                    this.Text = theFile;

                    var streamReader = openFileDialog1.OpenFile();

                    using (StreamReader reader = new StreamReader(streamReader))
                    {
                        richTextBox1.Text = reader.ReadToEnd();
                        reader.Close();
                    }
                }
            }
        }

        private void toolStripButtonFont_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog1 = new FontDialog();

            fontDialog1.Font = richTextBox1.SelectionFont;

            if (fontDialog1.ShowDialog() == DialogResult.OK & !String.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionFont = fontDialog1.Font;
            }
        }

        private void toolStripButtonColor_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog1 = new ColorDialog();

            colorDialog1.Color = richTextBox1.SelectionColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK & !String.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionColor = colorDialog1.Color;
            }
        }

        private void cutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox1.SelectedText, TextDataFormat.Text);
            richTextBox1.SelectedText = "";
        }

        private void toolStripButtonCut_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox1.SelectedText, TextDataFormat.Text);
            richTextBox1.SelectedText = "";
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox1.SelectedText, TextDataFormat.Text);
            richTextBox1.SelectedText = "";
        }

        private void pasteToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectedText = Clipboard.GetData(DataFormats.Text).ToString();
        }

        private void toolStripButtonPaste_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectedText = Clipboard.GetData(DataFormats.Text).ToString();
        }

        private void pasteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectedText = Clipboard.GetData(DataFormats.Text).ToString();
        }

        private void toolStripButtonCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(richTextBox1.SelectedText, TextDataFormat.Text);
        }

        private void toolStripButtonExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.ExitThread();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.ExitThread();
        }

        private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            using (StreamWriter streamWrite = new StreamWriter(theFile))
            {
                streamWrite.Write(richTextBox1.Text);
                streamWrite.Close();
            }
        }

        private void colorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog1 = new ColorDialog();

            colorDialog1.Color = richTextBox1.SelectionColor;

            if (colorDialog1.ShowDialog() == DialogResult.OK & !String.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionColor = colorDialog1.Color;
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            int words = 0;

            foreach (char c in richTextBox1.Text)
            {
                if (char.IsWhiteSpace(c))
                {
                    words++;
                }
            }
            toolStripStatusLabelWordCounter.Text = words.ToString();
        }

        private void boldToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Font defaultFont = SystemFonts.DefaultFont;
            if (boldToolStripMenuItem.Checked == true & !String.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionFont = new Font(defaultFont.FontFamily, defaultFont.Size, FontStyle.Bold);
            }
            else
            {
                richTextBox1.SelectionFont = new Font(defaultFont.FontFamily, defaultFont.Size, FontStyle.Regular);
            }
        }

        private void italicToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Font defaultFont = SystemFonts.DefaultFont;
            if (italicToolStripMenuItem.Checked == true & !String.IsNullOrEmpty(richTextBox1.Text))
            {
                richTextBox1.SelectionFont = new Font(defaultFont.FontFamily, defaultFont.Size, FontStyle.Italic);
            }
            else
            {
                richTextBox1.SelectionFont = new Font(defaultFont.FontFamily, defaultFont.Size, FontStyle.Regular);
            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
        }

        private void toolStripButtonEncrypt_Click(object sender, EventArgs e)
        {
            crypotography mycyrpotography = new crypotography();
            mycyrpotography.Show();
        }

        private void toolStripButtondecrypt_Click(object sender, EventArgs e)
        {
            Decrypt decrypt = new Decrypt();
            decrypt.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Word Processing Document 2022\nThe Latest and Greatest of it's time");
        }

        private void toolStripStatusLabelWordCount_Click(object sender, EventArgs e)
        {

        }
    }
}
