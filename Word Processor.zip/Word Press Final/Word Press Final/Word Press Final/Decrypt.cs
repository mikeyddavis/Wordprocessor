﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Word_Press_Final
{
    public partial class Decrypt : Form
    {
        public Decrypt()
        {
            InitializeComponent();
            textBoxPasscode2.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBoxPasscode2.Text == textBoxPasscode2.Text)
            {
                this.Hide();
            }
            else
            {
                labelPasswordCredentials.Text = "Invalid Password";
            }
        }
    }
}
